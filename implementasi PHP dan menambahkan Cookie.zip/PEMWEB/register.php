<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lynette Café - Login</title>
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    <header>
        <div class="logo">
            <img src="Foto/logo.png" width="140px" height="50px">
        </div>
            <ul class="nav-links">
                <li><a href="index.php">Home</a></li>
                <li><a href="#">Menu</a></li>
                <li><a href="#">Reserve</a></li>
                <li><a href="#">About</a></li>
                <li><a href="#">Contact</a></li>
                <li><a href="login.php" class="sign-in">Sign In</a></li>
            </ul>
        </div>
    </header>

    <section class="login-section">
        <div class="login-container">
            <h2>Welcome to Lynette Café</h2>
            <form action="#" method="POST">
                <div class="input-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="input-group">
                    <label for="username">Username</label>
                    <input type="username" id="username" name="username" required>
                </div>
                <div class="input-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <button type="submit" id="loginSubmit">Create account</button>
            </form>
            <p>Already have an account? <a href="login.php">Sign In</a></p>
        </div>
    </section>
    <div id="confirmModal" class="modal">
        <div class="modal-content">
            <h2>Are you sure want to register?</h2>
            <button id="confirmYes">Yes</button>
            <button id="confirmNo">No</button>
        </div>
    </div>
    <script src="js/login.js">Login</script>
</body>
</html>
